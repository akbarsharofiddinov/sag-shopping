import { createContext } from "react";

export const mainContext = createContext<IContext | undefined>(undefined);
