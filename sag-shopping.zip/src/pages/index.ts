export { default as Home } from "./home/Home";
export { default as Shop } from "./shop/Shop";