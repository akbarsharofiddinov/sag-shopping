export { default as LogoImg } from "./images/logo.svg";
export { default as UiBackGround } from "./images/ui-body_bg.svg";
export { default as client1 } from "./images/client/client-1.png";
export { default as usageInfo1 } from "./images/usage-information/image 11.png";
export { default as usageInfo2 } from "./images/usage-information/image 12.png";
export { default as usageInfo3 } from "./images/usage-information/image 13.png";